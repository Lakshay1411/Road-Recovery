here we have made web application for implementing web cam access and taking snaps shots.
>
>
>
further for admin purpose authentication page is also made.