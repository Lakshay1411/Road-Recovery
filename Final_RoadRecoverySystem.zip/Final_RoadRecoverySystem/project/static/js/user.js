$(document).ready(function(){
	$('#sum').click(function(){
		var usr=$('#usr').val();
		var mob=$('#num').val();
		var loc=$('#loc').val();
		$.ajax({
			url:'/process/',
			type:'POST',
			data:{'name':usr,'mobile':mob, 'locate':loc},
			success:function(response)
			{
				if(response=='success')
				{
					window.location.href='/'
				}
				if(response=='no')
				{
					alert('Username Password Mismatch')
				}
				if(response=='al')
				{
					alert('Mobile already registered for this location')
				}
			},
			error:function(xhr,textStatus,thrownError)
			{
				alert('error');
			}
		});
	});
}) 




