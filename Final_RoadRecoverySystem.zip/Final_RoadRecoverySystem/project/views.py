from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt,csrf_protect
from .models import admindata, complaintdata, counting
from django.contrib.auth.models import User

lst=[]

def mainpage(request):
	return render(request,'project/mainpage.html',{})
def index(request):
 	return render(request,'project/index.html',{})

def user(request):
 	return render(request,'project/user.html',{})

def admins(request):
 	return render(request,'project/login.html',{})

def Sort(sub_li): 
    l = len(sub_li) 
    for i in range(0, l): 
        for j in range(0, l-i-1): 
            if (sub_li[j][1] > sub_li[j + 1][1]): 
                tempo = sub_li[j] 
                sub_li[j]= sub_li[j + 1] 
                sub_li[j + 1]= tempo 
    return sub_li 
@csrf_exempt
def dels(request):
	us=counting.objects.all()
	lst=[]
	for i in us:
		lst.append(['A',int(i.A)])
		lst.append(['B',int(i.B)])
		lst.append(['C',int(i.C)])
		lst.append(['D',int(i.D)])
		lst.append(['E',int(i.E)])
	lst=Sort(lst)
	#print(lst)
	#print(lst[0][0])
	if(lst[-1][0]=='A'):
		counting.objects.filter(id=1).update(A=0)
	if(lst[-1][0]=='B'):
		counting.objects.filter(id=1).update(B=0)
	if(lst[-1][0]=='C'):
		counting.objects.filter(id=1).update(C=0)
	if(lst[-1][0]=='D'):
		counting.objects.filter(id=1).update(D=0)
	if(lst[-1][0]=='E'):
		counting.objects.filter(id=1).update(E=0)
		
	complaintdata.objects.filter(locations=lst[-1][0]).delete()
	return HttpResponse('success')
		
	
	
def mains(request):
	noA=0
	noB=0
	noC=0
	noD=0
	noE=0
	us=counting.objects.all()
	lst=[]
	for i in us:
		lst.append(['A',int(i.A)])
		lst.append(['B',int(i.B)])
		lst.append(['C',int(i.C)])
		lst.append(['D',int(i.D)])
		lst.append(['E',int(i.E)])
	lst=Sort(lst)
	print(lst)
	dic={}
	for i in range(len(lst)-1,-1,-1):
		if lst[i][1]>0:
			dic[lst[i][0]]=str(lst[i][1])
	print(dic)
	datas={"data":dic.keys(),"values":dic.values()}
	return render(request,'project/mains.html',datas)


@csrf_exempt
def process(request):
	noA=0
	noB=0
	noC=0
	noD=0
	noE=0
	print(request.POST)
	if(request.POST):
		names=request.POST.get('name')
		mobs=request.POST.get('mobile')
		locs=request.POST.get('locate')
		uss=complaintdata.objects.all()
		for i in uss:
			if(int(mobs)==int(i.mob) and locs==i.locations):
				return HttpResponse('al')
		
		usn=counting.objects.all()
		for i in usn:
			noA=int(i.A)
			noB=int(i.B)
			noC=int(i.C)
			noD=int(i.D)
			noE=int(i.E)
		print(type(noA))
		if(locs=='A'):
			noA=int(noA)+1
			counting.objects.filter(id=1).update(A=int(noA))

		if(locs=='B'):
			noB=int(noB)+1
			counting.objects.filter(id=1).update(B=int(noB))

		if(locs=='C'):
			noC=int(noC)+1
			counting.objects.filter(id=1).update(C=int(noC))

		if(locs=='D'):
			noD=int(noD)+1
			counting.objects.filter(id=1).update(D=int(noD))

		if(locs=='E'):
			noE=int(noE)+1
			counting.objects.filter(id=1).update(E=int(noE))
		
		input1=complaintdata.objects.create(name=names,mob=mobs,locations=locs)

	return HttpResponse('success')

@csrf_exempt
def login(request):
	k=0
	if(request.POST):
		print(request.POST)
		usrname=request.POST.get('usrname')
		passwrd=request.POST.get('pass')

		for j in admindata.objects.all():
			if(usrname==j.usrname and passwrd==j.password):
				print('found')
				k=1
				break;
	if(k==1):
		return HttpResponse('success')
	if(k==0):
		return HttpResponse('no')