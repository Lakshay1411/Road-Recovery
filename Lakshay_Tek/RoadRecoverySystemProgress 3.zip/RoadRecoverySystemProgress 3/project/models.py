from django.db import models


class complaintdata(models.Model):
    name=models.CharField(max_length=20)
    mob=models.IntegerField()
    locations=models.CharField(max_length=100)

class counting(models.Model):
 	A=models.IntegerField()
 	B=models.IntegerField()
 	C=models.IntegerField()
 	D=models.IntegerField()
 	E=models.IntegerField()

	
	
class admindata(models.Model):
	usrname=models.CharField(max_length=15)
	password=models.CharField(max_length=20)
	def __str__(self):
		return self.usrname

# Create your models here.
